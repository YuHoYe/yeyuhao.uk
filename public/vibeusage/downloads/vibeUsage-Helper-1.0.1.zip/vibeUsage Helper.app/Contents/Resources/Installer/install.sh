#!/bin/sh
set -eu
script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
label=com.yuho.vibeUsage.claude-refresh
install_dir="$HOME/.local/share/vibeUsage/claude-refresh-helper"
mailbox="$HOME/.local/share/vibeUsage/claude-refresh"
config_file="$HOME/.claude.json"
claude_bin=""
profile_directory=""
helper_source="$script_dir/claude-refresh-helper"
uninstall=false
dry_run=false
while [ "$#" -gt 0 ]; do
  case "$1" in
    --claude-bin) claude_bin="$2"; shift 2 ;;
    --config-file) config_file="$2"; shift 2 ;;
    --profile-directory) profile_directory="$2"; shift 2 ;;
    --mailbox) mailbox="$2"; shift 2 ;;
    --install-dir) install_dir="$2"; shift 2 ;;
    --binary) helper_source="$2"; shift 2 ;;
    --uninstall) uninstall=true; shift ;;
    --dry-run) dry_run=true; shift ;;
    --help)
      printf '%s\n' 'Usage: install.sh [--claude-bin PATH] [--config-file PATH] [--profile-directory PATH]' \
        '                  [--mailbox PATH] [--install-dir PATH] [--binary PATH] [--dry-run]' \
        '       install.sh --uninstall [--mailbox PATH] [--install-dir PATH] [--dry-run]'
      exit 0 ;;
    *) printf '%s\n' "Unknown option: $1" >&2; exit 2 ;;
  esac
done
if [ "$(id -u)" -eq 0 ]; then
  printf '%s\n' 'Run this installer as your normal macOS user, without sudo.' >&2
  exit 1
fi
absolute_directory() {
  case "$1" in /*) ;; *) printf '%s\n' 'All installation paths must be absolute.' >&2; exit 2 ;; esac
  case "$1" in /|"$HOME"|"$HOME/"|*/../*|*/..|*/./*) printf '%s\n' 'Choose a dedicated helper directory.' >&2; exit 2 ;; esac
}
absolute_directory "$install_dir"
absolute_directory "$mailbox"
if [ -L "$install_dir" ] || [ -L "$mailbox" ]; then
  printf '%s\n' 'Installation and mailbox directories must not be symbolic links.' >&2
  exit 2
fi
plist="$HOME/Library/LaunchAgents/$label.plist"
service="gui/$(id -u)/$label"
if [ "$uninstall" = true ]; then
  if [ "$dry_run" = true ]; then
    printf 'action=uninstall label=%s install_dir=%s mailbox=%s\n' "$label" "$install_dir" "$mailbox"
    exit 0
  fi
  /bin/launchctl bootout "$service" >/dev/null 2>&1 || true
  rm -f "$plist" "$install_dir/claude-refresh-helper" "$install_dir/install.sh" \
    "$mailbox/manifest.json" "$mailbox/request.json" "$mailbox/response.json" "$mailbox/state.json" "$mailbox/daemon.lock"
  printf 'Uninstalled %s. Claude configuration and existing sign-in were preserved.\n' "$label"
  exit 0
fi
if [ -z "$claude_bin" ]; then
  claude_bin=$(command -v claude || true)
fi
case "$claude_bin" in /*) ;; *) printf '%s\n' 'Pass --claude-bin with the absolute path to the official Claude Code CLI.' >&2; exit 2 ;; esac
case "$config_file" in /*) ;; *) printf '%s\n' '--config-file must be absolute.' >&2; exit 2 ;; esac
if [ -n "$profile_directory" ]; then
  case "$profile_directory" in /*) ;; *) printf '%s\n' '--profile-directory must be absolute.' >&2; exit 2 ;; esac
  if [ ! -d "$profile_directory" ]; then printf '%s\n' 'The supplied Claude profile directory does not exist.' >&2; exit 1; fi
fi
if [ ! -x "$claude_bin" ]; then printf '%s\n' 'The supplied Claude Code CLI is not executable.' >&2; exit 1; fi
if [ ! -f "$config_file" ]; then printf '%s\n' 'The supplied Claude configuration file does not exist. Sign in with the official CLI first.' >&2; exit 1; fi
if [ ! -x "$helper_source" ]; then
  printf '%s\n' 'Native helper binary is missing. Use the built helper package or pass --binary.' >&2
  exit 1
fi
if [ "$dry_run" = true ]; then
  printf 'action=install label=%s mailbox=%s claude_bin=%s config_file=%s install_dir=%s\n' "$label" "$mailbox" "$claude_bin" "$config_file" "$install_dir"
  exit 0
fi
umask 077
mkdir -p "$install_dir" "$HOME/Library/LaunchAgents"
chmod 700 "$install_dir"
/bin/launchctl bootout "$service" >/dev/null 2>&1 || true
temporary="$install_dir/.claude-refresh-helper.$$"
trap 'rm -f "$temporary"' EXIT HUP INT TERM
cp "$helper_source" "$temporary"
chmod 700 "$temporary"
mv -f "$temporary" "$install_dir/claude-refresh-helper"
if [ "$script_dir/install.sh" != "$install_dir/install.sh" ] && [ "$0" != "$install_dir/install.sh" ]; then
  cp "$0" "$install_dir/install.sh"
  chmod 700 "$install_dir/install.sh"
fi
set -- --prepare-installation --mailbox "$mailbox" --claude-bin "$claude_bin" --config-file "$config_file" \
  --launch-agent-plist "$plist" --helper-executable "$install_dir/claude-refresh-helper" --log-directory "$install_dir/logs"
if [ -n "$profile_directory" ]; then set -- "$@" --profile-directory "$profile_directory"; fi
"$install_dir/claude-refresh-helper" "$@"
/bin/launchctl bootstrap "gui/$(id -u)" "$plist"
/bin/launchctl kickstart -k "$service"
printf 'Installed %s. Select this refresh mailbox directory in vibeUsage:\n%s\n' "$label" "$mailbox"
